/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import static com.sun.corba.se.impl.util.Utility.printStackTrace;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import za.ac.tut.model.ejb.bl.ShoeFacadeLocal;

import za.ac.tut.model.entities.Shoe;
import za.ac.tut.model.entities.ShoeImage;

/**
 *
 * @author Philasande
 */
@MultipartConfig
public class AddShoeServlet extends HttpServlet {
    @EJB
    private ShoeFacadeLocal sfc;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String name = request.getParameter("name");
        String brand = request.getParameter("brand");
        
        int size = Integer.parseInt(request.getParameter("sizes"));
        
        Part image1Part = request.getPart("image1");
        Part image2Part = request.getPart("image2");
        
        String image1Name = image1Part.getSubmittedFileName();
        String image2Name = image2Part.getSubmittedFileName();
        
        byte[] image1Bytes = getImageBytes(image1Part);
        byte[] image2Bytes = getImageBytes(image2Part);
        
        Shoe shoe =createShoe(name,brand,size,image1Name,image2Name,image1Bytes,image2Bytes);
        sfc.create(shoe);
                
        RequestDispatcher disp = request.getRequestDispatcher("menu.jsp");
        disp.forward(request, response);
    }
    
     public byte[] getImageBytes(Part imagePart) {
        InputStream imageInputStream = null;
        
        byte[] imageBLOB = null;
        
        try {
            imageInputStream = imagePart.getInputStream();
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            
            byte[] buffer = new byte[1024];
            
            int bytes_read = 0;
            
            while( (bytes_read = imageInputStream.read(buffer)) != -1 ) {
                baos.write(buffer, 0, bytes_read);
            }   
            
            imageBLOB = baos.toByteArray();
        } catch (IOException ex) {
            printStackTrace();
            
        } finally {
            
            try {
                imageInputStream.close();
                
            } catch (IOException ex) {
                printStackTrace();
                
            }
        }
        
        return imageBLOB;
    }

    private Shoe createShoe(String name, String brand, int size, String image1Name, String image2Name, byte[] image1Bytes, byte[] image2Bytes) {
        Shoe shoe = new Shoe();
        
        List<ShoeImage> sm = new ArrayList<>();
        ShoeImage si = new ShoeImage(image1Name, image1Bytes);
        ShoeImage si1 = new ShoeImage(image2Name, image2Bytes);
        
        sm.add(si);
        sm.add(si1);
        
        shoe.setName(name);
        shoe.setBrand(brand);
        shoe.setSize(size);
        shoe.setImage(sm);
        
        return shoe;
    }
}
