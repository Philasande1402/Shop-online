/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.ejb.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.model.entities.ShoeImage;

/**
 *
 * @author Philasande
 */
@Local
public interface ShoeImageFacadeLocal {

    void create(ShoeImage shoeImage);

    void edit(ShoeImage shoeImage);

    void remove(ShoeImage shoeImage);

    ShoeImage find(Object id);

    List<ShoeImage> findAll();

    List<ShoeImage> findRange(int[] range);

    int count();
    
}
