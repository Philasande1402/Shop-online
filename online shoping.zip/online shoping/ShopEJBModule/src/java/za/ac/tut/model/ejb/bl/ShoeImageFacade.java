/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.ejb.bl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import za.ac.tut.model.entities.ShoeImage;

/**
 *
 * @author Philasande
 */
@Stateless
public class ShoeImageFacade extends AbstractFacade<ShoeImage> implements ShoeImageFacadeLocal {

    @PersistenceContext(unitName = "ShopEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ShoeImageFacade() {
        super(ShoeImage.class);
    }
    
}
