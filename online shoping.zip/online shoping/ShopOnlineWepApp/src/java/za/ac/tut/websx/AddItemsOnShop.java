/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.websx;

import static com.sun.corba.se.impl.util.Utility.printStackTrace;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import za.ac.tut.model.ejb.bl.ShoeFacadeLocal;
import za.ac.tut.model.entities.Shoe;
import za.ac.tut.model.entities.ShoeImage;

/**
 *
 * @author Philasande
 */
@MultipartConfig
public class AddItemsOnShop extends HttpServlet {
@EJB
    private ShoeFacadeLocal sfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("shoes");
        String brand = request.getParameter("brand");
        Integer size = Integer.parseInt(request.getParameter("size"));
        
        Part imagePart1 = request.getPart("image1");
        Part imagePart2 = request.getPart("image2");
        
        String imageName1 = imagePart1.getSubmittedFileName();
        String imageName2 = imagePart2.getSubmittedFileName();
        
        byte[] image1 = imageInputStream(imagePart1);
        byte[] image2 = imageInputStream(imagePart2);
        
        Shoe shoe = createShoes(name,brand,size,imageName1,imageName2,image1,image2);
        sfl.create(shoe);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_shoe_outcome.jsp");
        disp.forward(request, response);
        
    }

    private byte[] imageInputStream(Part imagePart1) {
        
        InputStream imageInputStream = null;
        
        byte[] imageBLOB = null;
        
        try {
            imageInputStream = imagePart1.getInputStream();
            
            ByteArrayOutputStream boas = new ByteArrayOutputStream();
            
            byte[] buffer = new byte[1024];
            
            int numRead =0;
            
            while((numRead = imageInputStream.read(buffer)) != -1){
                boas.write(buffer, 0, numRead);
            }
        imageBLOB = boas.toByteArray();
       } catch (IOException ex) {
           printStackTrace();
       }finally{
            try {
                imageInputStream.close();
                
            } catch (Exception e) {
                printStackTrace();
            }
        }
        
        return imageBLOB;
    }

    private Shoe createShoes(String name, String brand, Integer size, String imageName1, String imageName2, byte[] image1, byte[] image2) {
        Shoe sh = new Shoe();
        
        List<ShoeImage> si = new ArrayList<>();
        ShoeImage s1 = new ShoeImage(imageName1, image1);
        ShoeImage s2 = new ShoeImage(imageName2, image2);
        
        si.add(s1);
        si.add(s2);
        
        sh.setName(name);
        sh.setBrand(brand);
        sh.setSize(size);
        sh.setImage(si);
        
        return sh;
    }
      
}
